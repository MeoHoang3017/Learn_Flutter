package com.example.lab4_exercise

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
